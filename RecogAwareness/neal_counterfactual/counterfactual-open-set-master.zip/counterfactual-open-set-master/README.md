Code for Open Set Learning with Counterfactal Images, ECCV 2018

Dataset splits available at:

[cifar10](https://lwneal.com/openset-splits/cifar10.tar.gz)

[cifar100](https://lwneal.com/openset-splits/cifar100.tar.gz)

[mnist](https://lwneal.com/openset-splits/mnist.tar.gz)

[svhn](https://lwneal.com/openset-splits/svhn.tar.gz)

[tiny_imagenet](https://lwneal.com/openset-splits/tiny_imagenet.tar.gz)

*Check back soon for updates*
